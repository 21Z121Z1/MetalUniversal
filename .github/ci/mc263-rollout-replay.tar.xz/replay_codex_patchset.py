#!/usr/bin/env python3
"""Replay Codex apply_patch transcripts against a checked-out repository.

The input is the literal apply_patch format emitted by Codex. Paths are already
normalized to repository-relative names. The implementation is intentionally
strict: every delete/update preimage must exist uniquely (from the current
cursor onward first, then globally); otherwise the replay fails closed.
"""
from __future__ import annotations

import argparse
import dataclasses
from pathlib import Path
import re
import sys


@dataclasses.dataclass
class Operation:
    kind: str
    path: str
    body: list[str]
    patch_name: str


def parse_patchset(text: str) -> list[Operation]:
    lines = text.splitlines()
    operations: list[Operation] = []
    patch_name = "<unknown>"
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("# PATCH "):
            patch_name = line[len("# PATCH "):]
            i += 1
            continue
        m = re.fullmatch(r"\*\*\* (Add|Update|Delete) File: (.+)", line)
        if not m:
            i += 1
            continue
        kind, path = m.groups()
        if path.startswith("/") or ".." in Path(path).parts:
            raise RuntimeError(f"unsafe path in {patch_name}: {path}")
        body: list[str] = []
        i += 1
        while i < len(lines) and not lines[i].startswith("*** ") and not lines[i].startswith("# PATCH "):
            body.append(lines[i])
            i += 1
        operations.append(Operation(kind, path, body, patch_name))
    return operations


def locate(haystack: list[str], needle: list[str], start: int) -> int:
    if not needle:
        return start
    candidates = []
    for i in range(max(0, start), len(haystack) - len(needle) + 1):
        if haystack[i:i+len(needle)] == needle:
            candidates.append(i)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        # apply_patch uses surrounding context and the previous hunk cursor;
        # choosing the first forward match reproduces that behavior.
        return candidates[0]
    # A later hunk can legitimately target text above the previous replacement.
    candidates = []
    for i in range(0, len(haystack) - len(needle) + 1):
        if haystack[i:i+len(needle)] == needle:
            candidates.append(i)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise RuntimeError(f"ambiguous hunk preimage ({len(candidates)} matches)")
    # Last-resort whitespace-tolerant lookup. Codex apply_patch is tolerant of
    # insignificant indentation drift in context, but never of changed tokens.
    norm = lambda s: s.strip()
    nneedle = [norm(x) for x in needle]
    candidates = []
    for i in range(0, len(haystack) - len(needle) + 1):
        if [norm(x) for x in haystack[i:i+len(needle)]] == nneedle:
            candidates.append(i)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise RuntimeError(f"ambiguous whitespace-normalized hunk preimage ({len(candidates)} matches)")
    raise RuntimeError("hunk preimage not found")


def apply_update(path: Path, body: list[str], label: str) -> None:
    if not path.is_file():
        raise RuntimeError(f"{label}: update target does not exist: {path}")
    original = path.read_text(encoding="utf-8")
    had_final_newline = original.endswith("\n")
    lines = original.splitlines()

    hunks: list[list[str]] = []
    current: list[str] | None = None
    for line in body:
        if line == "@@":
            if current is not None:
                hunks.append(current)
            current = []
        else:
            if current is None:
                # update patches in this rollout always begin with @@; fail if
                # the transcript shape changes instead of guessing.
                raise RuntimeError(f"{label}: update body before first @@: {line!r}")
            current.append(line)
    if current is not None:
        hunks.append(current)
    if not hunks:
        raise RuntimeError(f"{label}: no update hunks")

    cursor = 0
    for hidx, hunk in enumerate(hunks, 1):
        old: list[str] = []
        new: list[str] = []
        for raw in hunk:
            if raw.startswith("+"):
                new.append(raw[1:])
            elif raw.startswith("-"):
                old.append(raw[1:])
            elif raw.startswith(" "):
                old.append(raw[1:])
                new.append(raw[1:])
            elif raw == "":
                # Empty context line is encoded as a single leading space in
                # normal apply_patch output. A bare empty line is accepted as
                # context for robustness with serialized transcripts.
                old.append("")
                new.append("")
            else:
                raise RuntimeError(f"{label}: unsupported hunk line: {raw!r}")
        try:
            pos = locate(lines, old, cursor)
        except Exception as exc:
            snippet = "\\n".join(old[:12])
            raise RuntimeError(f"{label}: hunk {hidx} failed for {path}: {exc}; preimage={snippet!r}") from exc
        lines[pos:pos+len(old)] = new
        cursor = pos + len(new)

    out = "\n".join(lines)
    if had_final_newline or out:
        out += "\n"
    path.write_text(out, encoding="utf-8")


def apply_operation(root: Path, op: Operation) -> None:
    path = root / op.path
    label = f"{op.patch_name}:{op.kind}:{op.path}"
    if op.kind == "Delete":
        if not path.exists():
            raise RuntimeError(f"{label}: delete target missing")
        path.unlink()
        return
    if op.kind == "Add":
        if path.exists():
            raise RuntimeError(f"{label}: add target already exists")
        content: list[str] = []
        for raw in op.body:
            if not raw.startswith("+"):
                raise RuntimeError(f"{label}: add line without '+': {raw!r}")
            content.append(raw[1:])
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(content) + ("\n" if content else ""), encoding="utf-8")
        return
    if op.kind == "Update":
        apply_update(path, op.body, label)
        return
    raise RuntimeError(f"unknown operation {op.kind}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("patchset")
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    operations = parse_patchset(Path(args.patchset).read_text(encoding="utf-8"))
    print(f"replaying {len(operations)} operations")
    for idx, op in enumerate(operations, 1):
        apply_operation(root, op)
        if idx % 25 == 0 or idx == len(operations):
            print(f"  applied {idx}/{len(operations)}: {op.patch_name}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"REPLAY_FAILED: {exc}", file=sys.stderr)
        raise
